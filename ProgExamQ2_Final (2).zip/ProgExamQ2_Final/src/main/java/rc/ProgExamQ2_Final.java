/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package rc;

import javax.swing.*;

/**
 *
 * @author RC_Student_Lab
 */
public class ProgExamQ2_Final {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new ProductSalesApplication().setVisible(true);
        });
    }
}