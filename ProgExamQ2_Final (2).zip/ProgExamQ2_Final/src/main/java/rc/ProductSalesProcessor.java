package rc;

public class ProductSalesProcessor implements IProductSales {
    private int[][] productSales;
    private final int salesLimit;

    public ProductSalesProcessor(int salesLimit) {
        this.salesLimit = salesLimit;
    }

    public void setProductSales(int[][] productSales) {
        this.productSales = productSales;
    }

    @Override
    public int[][] GetProductsSales() {
        return productSales;
    }

    @Override
    public int GetTotalSales() {
        if (productSales == null) return 0;
        
        int total = 0;
        for (int i = 0; i < productSales.length; i++) {
            for (int j = 0; j < productSales[i].length; j++) {
                total += productSales[i][j];
            }
        }
        return total;
    }

    @Override
    public int GetSalesOverLimit() {
        if (productSales == null) return 0;
        
        int count = 0;
        for (int i = 0; i < productSales.length; i++) {
            for (int j = 0; j < productSales[i].length; j++) {
                if (productSales[i][j] > salesLimit) {
                    count++;
                }
            }
        }
        return count;
    }

    @Override
    public int GetSalesUnderLimit() {
        if (productSales == null) return 0;
        
        int count = 0;
        for (int i = 0; i < productSales.length; i++) {
            for (int j = 0; j < productSales[i].length; j++) {
                if (productSales[i][j] <= salesLimit) {
                    count++;
                }
            }
        }
        return count;
    }

    @Override
    public int GetProductsProcessed() {
        return productSales != null ? productSales.length : 0;
    }

    @Override
    public double GetAverageSales() {
        if (productSales == null) return 0;
        
        int total = GetTotalSales();
        int count = 0;
        for (int i = 0; i < productSales.length; i++) {
            count += productSales[i].length;
        }
        return count > 0 ? (double) total / count : 0;
    }
}