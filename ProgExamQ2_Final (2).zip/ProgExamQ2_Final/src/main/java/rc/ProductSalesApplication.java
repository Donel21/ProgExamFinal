package rc;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

public class ProductSalesApplication extends JFrame {
    private JTextArea textArea;
    private JLabel yearsProcessedLabel;
    private JButton loadButton, saveButton;
    private ProductSalesProcessor salesProcessor;
    private final int SALES_LIMIT = 500;

    public ProductSalesApplication() {
        initializeGUI();
        salesProcessor = new ProductSalesProcessor(SALES_LIMIT);
    }

    private void initializeGUI() {
        setTitle("Product Sales Application");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Create a menu bar
        createMenuBar();

        // Jpanel
        JPanel mainPanel = new JPanel(new BorderLayout());
        
        // Jpanel
        JPanel buttonPanel = new JPanel();
        loadButton = new JButton("Load Product Data");
        saveButton = new JButton("Save Product Data");
        
        buttonPanel.add(loadButton);
        buttonPanel.add(saveButton);
        
        // Jtext code
        textArea = new JTextArea(10, 30);
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        
        // Jpanel code
        JPanel resultsPanel = new JPanel(new GridLayout(0, 2));
        yearsProcessedLabel = new JLabel("Years Processed: 0");
        resultsPanel.add(new JLabel("Years Processed:"));
        resultsPanel.add(yearsProcessedLabel);
        
        // Adding buttons
        loadButton.addActionListener(new LoadButtonListener());
        saveButton.addActionListener(new SaveButtonListener());
        
        // Add components to main panel
        mainPanel.add(buttonPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(resultsPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
        pack();
        setLocationRelativeTo(null);
    }

    private void createMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        
        // File menu
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitMenuItem = new JMenuItem("Exit");
        exitMenuItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitMenuItem);
        
        // Tools menu
        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem loadMenuItem = new JMenuItem("Load Product Data");
        JMenuItem saveMenuItem = new JMenuItem("Save Product Data");
        JMenuItem clearMenuItem = new JMenuItem("Clear");
        
        loadMenuItem.addActionListener(new LoadButtonListener());
        saveMenuItem.addActionListener(new SaveButtonListener());
        clearMenuItem.addActionListener(e -> {
            textArea.setText("");
            yearsProcessedLabel.setText("Years Processed: 0");
        });
        
        toolsMenu.add(loadMenuItem);
        toolsMenu.add(saveMenuItem);
        toolsMenu.add(clearMenuItem);
        
        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        
        setJMenuBar(menuBar);
    }

    private class LoadButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Sample data from memory
            int[][] productData = {
                {300, 150, 700}, // Year 1: Microphone, Speakers, Mixing Desk
                {250, 200, 600}  // Year 2: Microphone, Speakers, Mixing Desk
            };
            
            salesProcessor.setProductSales(productData);
            
            // Display results
            textArea.setText("Product Sales Data:\n");
            textArea.append("Year 1 - Microphone: $300, Speakers: $150, Mixing Desk: $700\n");
            textArea.append("Year 2 - Microphone: $250, Speakers: $200, Mixing Desk: $600\n\n");
            textArea.append("Total Sales: " + salesProcessor.GetTotalSales() + "\n");
            textArea.append("Average Sales: " + String.format("%.2f", salesProcessor.GetAverageSales()) + "\n");
            textArea.append("Sales over limit: " + salesProcessor.GetSalesOverLimit() + "\n");
            textArea.append("Sales under limit: " + salesProcessor.GetSalesUnderLimit() + "\n");
            
            yearsProcessedLabel.setText("Years Processed: " + salesProcessor.GetProductsProcessed());
        }
    }

    private class SaveButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try (PrintWriter writer = new PrintWriter(new FileWriter("data.txt"))) {
                writer.println("DATA LOG");
                writer.println("*******************************");
                writer.println("Total Sales: " + salesProcessor.GetTotalSales());
                writer.println("Average Sales: " + String.format("%.2f", salesProcessor.GetAverageSales()));
                writer.println("Sales over limit: " + salesProcessor.GetSalesOverLimit());
                writer.println("Sales under limit: " + salesProcessor.GetSalesUnderLimit());
                writer.println("*******************************");
                JOptionPane.showMessageDialog(null, "Data saved to data.txt");
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(null, "Error saving file: " + ex.getMessage());
            }
        }
    }
}