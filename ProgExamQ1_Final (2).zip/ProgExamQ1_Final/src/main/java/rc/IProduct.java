package rc;

public interface IProduct {
    int TotalSales(int[][] productsSales);
    double AverageSales(int[][] productsSales);
    int MaxSale(int[][] productsSales);
    int MinSale(int[][] productsSales);
}