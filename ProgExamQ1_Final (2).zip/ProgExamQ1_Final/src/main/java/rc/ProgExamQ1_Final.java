/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package rc;

/**
 *
 * @author RC_Student_Lab
 */
public class ProgExamQ1_Final {

    public static void main(String[] args) {
        // Product sales data for two years
        int[][] productSales = {
            {300, 150, 700}, // Year 1
            {250, 200, 600}  // Year 2
        };
        
        // create a class
        ProductSales salesCalculator = new ProductSales();
        
        // Calculation
        int totalSales = salesCalculator.TotalSales(productSales);
        double averageSales = salesCalculator.AverageSales(productSales);
        int maxSale = salesCalculator.MaxSale(productSales);
        int minSale = salesCalculator.MinSale(productSales);
        
        // Display the report
        System.out.println("============================");
        System.out.println("PRODUCT SALES REPORT - 2025");
        System.out.println("============================");
        System.out.println("Total sales: " + totalSales);
        System.out.println("Average sales: " + averageSales);
        System.out.println("Maximum sales: " + maxSale);
        System.out.println("Minimum sales: " + minSale);
    }
}